package id.cloudplay.lite;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.view.WindowManager;
import android.webkit.SafeBrowsingResponse;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.graphics.Color;
import android.graphics.Typeface;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Build;
import android.view.Gravity;
import android.widget.Toast;

public class MainActivity extends Activity {
    private static final String PREFS = "cloudplay_settings";
    private static final String KEY_URL = "server_url";
    private WebView webView;
    private SharedPreferences prefs;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_SECURE,
                             WindowManager.LayoutParams.FLAG_SECURE);
        prefs = getSharedPreferences(PREFS, MODE_PRIVATE);
        showSetup();
    }

    private void showSetup() {
        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setPadding(28, 36, 28, 28);
        layout.setBackgroundColor(Color.rgb(12, 17, 31));

        TextView title = new TextView(this);
        title.setText("CloudPlay Lite");
        title.setTextSize(28);
        title.setTypeface(null, Typeface.BOLD);
        title.setTextColor(Color.WHITE);
        layout.addView(title);

        TextView subtitle = new TextView(this);
        subtitle.setText("Hubungkan ke server cloud gaming Anda melalui HTTPS.");
        subtitle.setTextColor(Color.LTGRAY);
        subtitle.setTextSize(15);
        subtitle.setPadding(0, 12, 0, 18);
        layout.addView(subtitle);

        EditText url = new EditText(this);
        url.setSingleLine(true);
        url.setHint("https://game.domain-anda.com");
        url.setTextColor(Color.WHITE);
        url.setHintTextColor(Color.GRAY);
        url.setText(prefs.getString(KEY_URL, ""));
        url.setInputType( android.text.InputType.TYPE_CLASS_TEXT |
                          android.text.InputType.TYPE_TEXT_VARIATION_URI);
        layout.addView(url);

        Button connect = new Button(this);
        connect.setText("Hubungkan");
        layout.addView(connect);
        TextView note = new TextView(this);
        note.setText("Catatan: aplikasi ini adalah klien. Server GPU, layanan streaming WebRTC, dan katalog game perlu disiapkan terpisah.");
        note.setTextColor(Color.LTGRAY);
        note.setPadding(0, 18, 0, 0);
        layout.addView(note);

        connect.setOnClickListener(v -> {
            String value = url.getText().toString().trim();
            if (!isValidHttpsUrl(value)) {
                Toast.makeText(this, "Masukkan alamat HTTPS yang valid.", Toast.LENGTH_LONG).show();
                return;
            }
            prefs.edit().putString(KEY_URL, value).apply();
            showGameClient(value);
        });
        setContentView(layout);
    }

    private boolean isValidHttpsUrl(String value) {
        try {
            Uri uri = Uri.parse(value);
            return "https".equalsIgnoreCase(uri.getScheme())
                && uri.getHost() != null
                && uri.getUserInfo() == null;
        } catch (Exception e) { return false; }
    }

    private void showGameClient(String url) {
        webView = new WebView(this);
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true); // Needed by the WebRTC game-streaming frontend.
        settings.setDomStorageEnabled(true);
        settings.setMediaPlaybackRequiresUserGesture(false);
        settings.setAllowFileAccess(false);
        settings.setAllowContentAccess(false);
        settings.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            settings.setSafeBrowsingEnabled(true);
        }

        final String allowedHost = Uri.parse(url).getHost();
        webView.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri target = request.getUrl();
                return !"https".equalsIgnoreCase(target.getScheme())
                    || target.getHost() == null
                    || !allowedHost.equalsIgnoreCase(target.getHost());
            }
            @Override public void onPageFinished(WebView view, String page) {
                super.onPageFinished(view, page);
            }
        });
        webView.setWebChromeClient(new WebChromeClient());
        setContentView(webView);
        webView.loadUrl(url);
    }

    @Override public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack();
        else showSetup();
    }

    @Override protected void onDestroy() {
        if (webView != null) {
            webView.loadUrl("about:blank");
            webView.destroy();
            webView = null;
        }
        super.onDestroy();
    }
}
