# CloudPlay Lite — Android client starter

CloudPlay Lite adalah kerangka aplikasi Android ringan untuk mengakses **server cloud gaming milik Anda**. Ini belum merupakan layanan cloud gaming lengkap dan tidak menyertakan game, server GPU, maupun layanan streaming.

## Yang sudah ada
- Android native Java, tanpa framework UI besar.
- Minimum Android 6.0 (API 23).
- Hanya meminta izin INTERNET.
- Memaksa HTTPS dan menolak mixed content.
- WebView membatasi navigasi ke host HTTPS yang dikonfigurasi.
- Android backup dimatikan dan screenshot diblokir pada activity.
- Pengaturan alamat server disimpan lokal.

## Yang masih harus disediakan
1. Server GPU dengan encoder video hardware (misalnya NVIDIA NVENC atau AMD AMF).
2. Backend sesi/autentikasi dan manajemen antrean.
3. Frontend HTTPS yang mengimplementasikan streaming WebRTC dan kontrol game.
4. TURN/STUN untuk koneksi WebRTC pada jaringan yang membutuhkannya.
5. Katalog game yang legal digunakan dan sistem isolasi tiap sesi pengguna.

## Menghubungkan
Setelah APK dipasang, masukkan URL frontend cloud gaming Anda, misalnya `https://play.domain-anda.com`. URL contoh tersebut bukan server aktif. Frontend harus kompatibel dengan WebView Android dan WebRTC.

## Build
Buka folder ini di Android Studio (disarankan versi stabil terbaru), tunggu Gradle sync, lalu pilih **Build > Build Bundle(s) / APK(s) > Build APK(s)**.

Atau dengan Gradle yang sudah terpasang:
```bash
gradle assembleDebug
```
APK debug akan berada di `app/build/outputs/apk/debug/app-debug.apk`.

## Catatan keamanan sebelum rilis
- Gunakan HTTPS dengan sertifikat valid; jangan mengaktifkan HTTP cleartext.
- Autentikasi harus dilakukan di backend; jangan menanam API key rahasia di APK.
- Terapkan rate limiting, token sesi berumur pendek, dan logout/revokasi sesi.
- Jalankan setiap game dalam VM/container terisolasi tanpa akses ke data host atau sesi lain.
- Terapkan patch OS, driver GPU, encoder, dan komponen streaming secara rutin.
- Audit dependensi, scan artefak build, dan lakukan penetration test sebelum distribusi.
- Jangan mengizinkan URL server sembarang pada versi produksi; gunakan domain yang Anda kendalikan dan pinning/certificate policy yang dirancang dengan benar.

## Status
Prototype klien awal — belum terhubung ke server dan belum dapat memainkan game sampai backend cloud gaming tersedia.
